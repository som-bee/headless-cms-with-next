define("epi-cms/contentediting/editors/RangeNumberEditor", [
    "dojo/_base/declare",
    "dijit/form/NumberSpinner"
], function (declare, NumberSpinner) {

    return declare([NumberSpinner], {
        // tags:
        //      internal

        adjust: function (/*Object*/ val, /*Number*/ delta) {
            var tc = this.constraints,
                v = isNaN(val),
                gotMax = !isNaN(tc.max),
                gotMin = !isNaN(tc.min);

            if (v && gotMax && gotMin && tc.max >= 0 && tc.min <= 0) {
                return 0;
            } else {
                return this.inherited(arguments);
            }
        }
    });
});
